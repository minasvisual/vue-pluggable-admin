<template>
  <slot></slot>
</template>
 