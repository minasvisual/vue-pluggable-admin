<template>
  <pre>
    {{ 'Editor' }}
  </pre>
</template>
 