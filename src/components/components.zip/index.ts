import Table from './Table.vue'

export {
  Table
}